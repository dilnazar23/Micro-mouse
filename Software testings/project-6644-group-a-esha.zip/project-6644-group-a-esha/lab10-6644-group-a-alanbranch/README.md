# Lab10: Computer Vision

## Learning Outcome

- Use OpenCV to apply CV techniques (i.e. perspective transforms, colour thresholding, morphological operations, etc.) onto an image to extract key information.

---

## Prerequisites

### Related Lectures

- Vision I.
- Vision II.

### Extra Resources

- [MTRN3100 Python Tutorials](https://github.com/drliaowu/MTRN3100_Python_Tutorials)
- [MTRN3100 Lecture Vision I Code](https://github.com/drliaowu/MTRN3100_Lecture_Vision_I)
- [MTRN3100 Lecture Vision II Code](https://github.com/drliaowu/MTRN3100_Lecture_Vision_II)

### Prelab Video

No prelab videos this week. Please refer to CV lectures.

### Kit

This lab will require:

- $1 \times$ camera (provided with maze)
- $1 \times$ laptop
- $1 \times$ bluetooth module setup

---

## Prelab

1. (required) Set up your Jupyter development environment.

    Use the following commands to upgrade the Python package manager and install additional libraries:
    ```
    python3 -m pip install --upgrade pip
    python3 -m pip install -r requirements.txt
    ```

1. (1 mark) Open `prelab.ipynb`, print `Hello World!`.


1. (1 mark) Read in `prelab_image.png` in the `test` folder and display it using `imshow` and `show` in RGB format.


1. (3 marks) Use colour thresholding and masking to show three separate masks of: <span style="color:blue;">blue</span> shapes only, <span style="color:green;">green</span> shapes only, and <span style="color:red;">red</span> shapes only.

    Hint: You may need to use `bitwise` operations.


1. (2 marks) Draw contour outline of ALL shapes and display its moment and area.


1. (2 marks) Perspective transform `prelab_image_warped1.png` and `prelab_image_warped2.png` to the expected image i.e. `prelab_image.png`.


---

## Lab

### Instruction

1. (1 mark) Select one of the `camera` images from the test folder and show the image in HSV format.

    Below is an example of showing the image:

    ![read_example](./README/read_example.svg)

1. (2 marks) Apply a perspective transform onto the test image.

    Below is an example of a transformed image:

    ![transformed_example](./README/transformed_example.svg)


1. (2 marks) Detect the walls and create a mask for only the walls.

    Below is an example of a masked image of just the maze walls:

    ![mask_example](./README/mask_example.svg)


1. (3 marks) Convert the detected walls to ASCII art.

    Below is an example of the test image being converted to ASCII art:

    ```
     --- --- --- --- --- --- --- --- --- 
    |                       |           |
     ---                         ---     
    |                   |   |   |   |   |
     --- --- --- --- --- ---             
    |           |           |       |   |
     --- ---             --- --- --- --- 
    |           |   |   |   |           |
                                        
    |           |           |           |
     --- --- --- --- --- --- --- --- --- 
    ```


1. (1 mark) Send the ASCII string from the off-board computer to the robot via bluetooth.

    You may manually type the string out i.e. you do not need to use the CV program to automatically transmit the string.

    Note that some bluetooth modules may display the string weirdly due to font. You may replace the space character with another character like `.` or `*`.


1. (1 mark) Individually answer a demo question orally.


1. (1 mark) Connect the maze camera to an off-board computer (e.g. computer or laptop) and capture an image of the maze.

    Display the image on the off-board computer.


1. (0 marks) Make your code more robust and reliable to different test cases by testing each of the images in the `test` folder.

