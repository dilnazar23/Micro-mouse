class Car {
    public:
        // Car();
        // ~Car();
        
        float currX;
        float currY;
        float currHead;
        char displayHead;
        float rotatationSpeed;
        float linearSpeed;
        float distanceLeft;
        float distanceFront;
        float distanceRight;
        float leftWheelSpeed;
        float rightWheelSpeed;
        float initialX = 0.0;
        float initialY = 0.0;
        float initialHead = -0.02;
        int walls[3] = {0,0,0};
        void getBluetoothStatus ();
        void getMotorStatus ();
        void getLCDStatus ();
        void getLIDARStatus ();
        void getUltrasonicStatus ();
        void getIMUStatus ();
};



