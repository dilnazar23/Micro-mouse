#include "Robot.hpp"
#include "LiquidCrystalIO.h"

// template <class T>


void LCD_Print(&LiquidCrystal lcd, &Robot robot) {
    lcd.print("[");
    lcd.print(robot.currX);
    lcd.print(",");
    lcd.print(robot.currY);
    lcd.print(",");
    lcd.print(robot.currHead);
    lcd.print("]");
};
