#pragma once

#include <Arduino.h>
#include <ICM_20948.h>

namespace mtrn3100 {

class Motor {
public:
    // COMPLETE THIS CONSTRUCTOR.
    Motor(uint8_t analog, uint8_t input1, uint8_t input2) : analog_pin(analog),input1_pin(input1),input2_pin(input2) {
      pinMode(analog_pin,OUTPUT);
      pinMode(input1_pin,OUTPUT);
      pinMode(input2_pin,OUTPUT);
      };

    // COMPLETE THIS FUNCTION.
    // This function sets the PWM of the motor and returns nothing. This function accepts a signed PWM signal with range
    // [-255, 255]. Any values outside this range are clamped to the limits.
    void setPWM(int16_t pwm) {
      if (pwm<-255||pwm>255){
        digitalWrite(input1_pin,LOW);
        digitalWrite(input2_pin,LOW);
        }
      else if (pwm>0){
        digitalWrite(input1_pin,HIGH);
        digitalWrite(input2_pin,LOW);
        analogWrite(analog_pin,pwm);
        } 
      else if (pwm<0){
        digitalWrite(input1_pin,LOW);
        digitalWrite(input2_pin,HIGH);
        analogWrite(analog_pin,pwm);
        }
      else if (pwm=0){
        digitalWrite(input1_pin,LOW);
        digitalWrite(input2_pin,LOW);
      }
      }

private:
    const uint8_t analog_pin;
    const uint8_t input1_pin;
    const uint8_t input2_pin;
};

class IMU {
public:
    IMU(bool adrValue = 0) : adrValue(adrValue) {}

    void begin() {
        bool initialised = false;
        while (!initialised) {
            icm.begin(Wire, adrValue);
            if (icm.status != ICM_20948_Stat_Ok) {
                delay(500);
                prevTime = micros();
            } else {
                initialised = true;
            }
        }

        bool success = true;

        // Enable sensors
        success &= (icm.initializeDMP() == ICM_20948_Stat_Ok);
        success &= (icm.enableDMPSensor(INV_ICM20948_SENSOR_GAME_ROTATION_VECTOR) == ICM_20948_Stat_Ok);
        success &= (icm.enableDMPSensor(INV_ICM20948_SENSOR_ACCELEROMETER) == ICM_20948_Stat_Ok);

        success &= (icm.setDMPODRrate(DMP_ODR_Reg_Quat6, 0) == ICM_20948_Stat_Ok);
        success &= (icm.setDMPODRrate(DMP_ODR_Reg_Accel, 0) == ICM_20948_Stat_Ok);

        // Enable and clear buffers
        success &= (icm.enableFIFO() == ICM_20948_Stat_Ok);
        success &= (icm.enableDMP() == ICM_20948_Stat_Ok);
        success &= (icm.resetDMP() == ICM_20948_Stat_Ok);
        success &= (icm.resetFIFO() == ICM_20948_Stat_Ok);
    }
        bool dataReady() { return icm.dataReady(); }

    void reset() {
        vx = 0, vy = 0, vz = 0;
        r = 0, p = 0, y = 0;
        px = 0, py = 0, pz = 0;
    }
    
    float yaw() { return y; }

private:
    ICM_20948_I2C icm;  // Instantiate IMU object from Sparkfun.
    icm_20948_DMP_data_t data;

    const bool adrValue;

    uint32_t prevTime = 0;

    // Linear.
    float ax, ay, az;
    float vx, vy, vz;

    // Calibration.
    float offsetX, offsetY, offsetZ, offsetYaw;

    // Angular.
    float r = 0, p = 0, y = 0;

    // Global Pose.
    float px = 0, py = 0, pz = 0;
};

class Encoder {
public:
    Encoder(uint8_t enc1, uint8_t enc2, void* callback) : encoder1_pin(enc1), encoder2_pin(enc2) {
        pinMode(encoder1_pin, INPUT_PULLUP);
        pinMode(encoder2_pin, INPUT_PULLUP);
        attachInterrupt(digitalPinToInterrupt(encoder1_pin), callback, RISING);
    }
    void readEncoder() {
        noInterrupts();
        if (digitalRead(encoder2_pin)) {
            direction = 1;
        } else {
            direction = -1;
        }
        interrupts();
        
        // Get motor position.
        noInterrupts();
        const uint16_t counts_per_revolution = 265;       
        position = position + static_cast<float>(2.0*PI*direction)/counts_per_revolution;
        interrupts();
    }
    

public:
    const uint8_t encoder1_pin;
    const uint8_t encoder2_pin;
    int8_t direction  ;
    float position =0;
    uint32_t prev_time;
    bool read = false;
};

// Not inside Encoder because only free functions are interruptable.
void setEncoder(mtrn3100::Encoder& encoder) { encoder.read = true; }
void readLeftEncoder();
void readRightEncoder();
mtrn3100::Encoder l_encoder(18, 22, readLeftEncoder);
mtrn3100::Encoder r_encoder(19, 23, readRightEncoder);
void readLeftEncoder() { l_encoder.readEncoder(); }
void readRightEncoder() { r_encoder.readEncoder(); }
// Set up IMU
mtrn3100::IMU imu(0);
namespace encoder_odometry {
// Pose estimated from encoder odometry.
float x = 0;
float y = 0;
float h = 0;

// Robot parameters.
float R = 25;  // mm.
float L = 50;  // mm.

// Last wheel positions.
float lastLPos = 0;
float lastRPos = 0;

void update() {
    const float leftValue = l_encoder.position;
    const float rightValue = r_encoder.position;

    const float tL = leftValue-lastLPos;  // Change in left wheel position.
    const float tR = rightValue-lastRPos;  // Change in right wheel position.
    const float delta_h = (R/(2*L))*(tR-tL);
    const float delta_s = (R/2)*(tR+tL);

    x = x + delta_s* cos(h);
    y = y + delta_s* sin(h);
    h = h + delta_h;
    
    lastLPos = leftValue;
    lastRPos = rightValue;

}

}  // namespace encoder_odometry
// end esha insert
// function to print odometry results 
//  printing the pose 
void printPose() {
  // this for bluettoth???
      encoder_odometry::update();
  if (Serial.available() > 0 ) {
        Serial.print("[");
        Serial.print(encoder_odometry::x);
        Serial.print(",");
        Serial.print(encoder_odometry::y);
        Serial.print(",");
        Serial.print(imu.yaw());
        Serial.println("]"); 
    }

    if (Serial3.available()) {
        Serial.print("[");
        Serial.print(encoder_odometry::x);
        Serial.print(",");
        Serial.print(encoder_odometry::y);
        Serial.print(",");
        Serial.print(imu.yaw());
        Serial.println("]");   
    }
// this just prints to serial monitor but works
    // encoder_odometry::update();
    // Serial.print("[");
    // Serial.print(encoder_odometry::x);
    // Serial.print(",");
    // Serial.print(encoder_odometry::y);
    // Serial.print(",");
    // Serial.print(imu.yaw());
    // Serial.println("]");
}


}  // namespace mtrn3100