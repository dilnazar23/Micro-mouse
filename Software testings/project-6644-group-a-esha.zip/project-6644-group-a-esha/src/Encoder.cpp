#pragma once

#include <Arduino.h>

namespace mtrn3100 {

class Encoder {
public:
    Encoder(uint8_t enc1, uint8_t enc2, void* callback) : encoder1_pin(enc1), encoder2_pin(enc2) {
        pinMode(encoder1_pin, INPUT);
        pinMode(encoder2_pin, INPUT);
        attachInterrupt(digitalPinToInterrupt(encoder1_pin), callback, RISING);
    }
    int num_pulses=0;
    //void countPulses() { num_pulses++; }
    void readEncoder() {
        num_pulses++;
        noInterrupts();
        if (digitalRead(encoder2_pin)) {
            direction = 1;
        } else {
            direction = -1;
        }
        interrupts();
        // reades the state of the encoder2 pins and determines the direction of rotation - if pin is high then rotaing in one direction otherwise low rotating on opposite direction

        // Get motor position.
        // COMPLETE THIS BLOCK.
        noInterrupts();
        const uint16_t counts_per_revolution = 265;       
        // position = static_cast<int>(num_pulses*3.14*2*direction)/counts_per_revolution;
        const float radians_per_count = (2*Pi) / counts_per_revolution; 
        static uint16_t prev_counts = 0;
        uint16_t counts = (digitalRead(encoder1_pin) << 1) | digitalRead(encoder2_pin);
        int16_t count_diff = conts - prev_counts;

        if (count_diff > 0) {
            if (count_diff == 3) {
                count_diff = -1;
            }
        } else if (count_diff < 0) {
            if (count_diff == -3) {
                count_diff = 1;
            }
        }

        position += count_diff * radians_per_count;
        prev_counts = counts;
        
        interrupts();

        // count diff is correction mechanism to account for transition glitches or count jumps
        // if cound_diff is positive = 3 means there was count jump from highest value to lowest value, so means should = -1
        // same if negative = 03 means jump from lowest to highest, so correct = 1
        // motor position is 
    }
    

public:
    const uint8_t encoder1_pin;
    const uint8_t encoder2_pin;
    int8_t direction;
    float position = 0;
    uint32_t prev_time;
    bool read = false;
};
+
// Not inside Encoder because only free functions are interruptable.
void setEncoder(mtrn3100::Encoder& encoder) { encoder.read = true; }

}  // namespace mtrn3100